# Google Sheet setup (50 bookings per day) - takes about 5 minutes

1. Go to sheets.google.com and create a new blank sheet. Name it "Shiva Sathvika Bookings".
2. In the sheet, click **Extensions > Apps Script**.
3. Delete everything in the editor, then paste the full contents of **Code.gs** (in this folder). Click Save.
4. Click **Deploy > New deployment**.
   - Click the gear icon and choose **Web app**.
   - Execute as: **Me**
   - Who has access: **Anyone**   (needed so patients can book; they can only add a booking and see slot counts, never read the sheet)
   - Click **Deploy** and allow the permissions (Google may show "unsafe" - click Advanced > Go to project).
5. Copy the **Web app URL** (it ends with /exec).
6. Open **script.js** in the website folder, find this line near the top of the booking section:

       const BOOKING_API = "";

   and paste the URL between the quotes:

       const BOOKING_API = "https://script.google.com/macros/s/XXXXXXXX/exec";

7. Upload the website again. Done.

## How it works
- Each booking is added as a row in the **Today** tab (green) or the **Tomorrow** tab (blue). Tabs are created automatically.
- The website shows "Today - 23 slots left" and "Tomorrow - 50 slots left". When a day reaches 50 it shows "Full" and cannot be chosen.
- The limit is checked on the server, so two people booking at the same moment cannot go above 50.
- If a patient cancels, choose **Cancelled** in the Status column of that row (drop-down). The row turns red and the slot becomes free again.
- To change the limit, edit `LIMIT_PER_DAY` in Code.gs, then **Deploy > Manage deployments > Edit > New version > Deploy**.
- Whenever you change Code.gs you must create a New version like this, otherwise the old code keeps running.
- Day counting uses Indian time (midnight IST).

## Updating Code.gs later (important)
1. Open the sheet, then Extensions > Apps Script.
2. Delete the old code, paste the new Code.gs, and Save.
3. Deploy > Manage deployments > pencil icon > Version: **New version** > Deploy.
   The link stays the same, so you do not change anything on the website.

## Daily use
- **Send confirmation** (last column): click it on a booking row. WhatsApp opens with the message
  "Slot booked for Today, 7 Nov. Our team will reach your home and collect the sample." ready to send to the patient.
- **Patient did not send the WhatsApp message?** The booking is still in the sheet with their name, phone and address.
  Click "Send confirmation" to contact them.
- **Test or cancelled booking:** type **Cancelled** in the Status column. The slot becomes free again.
- **Same person books twice on the same day:** it does not use a second slot. They get their first booking number again.

## Booking window (4 PM rule)
- **Today's slots:** open from yesterday morning until today 4 PM (IST). After 4 PM, Today shows "Closed after 4 PM".
- **Tomorrow's slots:** open from today morning until tomorrow 4 PM.
- Each day has 50 slots. When full, the patient sees: "All 50 slots are booked. Please try the next day."

## If booking does not save (even with an empty sheet)
The link in `BOOKING_API` must be the **Web app URL** ending with **/exec**, like
`https://script.google.com/macros/s/AKfy.../exec`. A link containing `/macros/library/` will NOT work.
Get it from Deploy > Manage deployments > Web app > Copy. Then redeploy as a **New version**.

## Security (please do all of these)
1. **Sheet sharing:** in the sheet click **Share**. General access must be **Restricted** and only your own account listed. Anyone who can edit the sheet can also edit the script, so never add other editors.
2. **Google account:** turn on **2-Step Verification** for the account that owns the sheet (myaccount.google.com > Security). A dedicated Google account just for the lab is best. Sign out on shared computers.
3. **After pasting the new Code.gs:** Deploy > Manage deployments > pencil > **New version** > Deploy. Google may ask you to allow one new permission ("connect to an external service"). That is for the spam check below. Click Allow.
4. **Limits built in:** one phone number can hold at most 3 slots per day (`MAX_PER_PHONE_PER_DAY`), and the whole website accepts at most 8 booking attempts per minute (`MAX_PER_MINUTE`). Patients never see technical error text; the details are in Apps Script > Executions.
5. **Patient details are not saved in the patient's browser.** The form is empty every visit and is cleared after booking.

## Spam protection with Cloudflare Turnstile (free, recommended)
Stops bots from filling all 50 slots with fake bookings. It stays OFF until you add both keys below.
1. Go to dash.cloudflare.com, create a free account, open **Turnstile** > **Add widget**. Add your website domain. Choose **Managed**.
2. Copy the **Site key** and the **Secret key**.
3. Website: in **script.js** put the Site key in `const TURNSTILE_SITE_KEY = "";` and upload the website again.
4. Google: Apps Script > **Project Settings** (gear icon) > **Script properties** > Add property. Name: `TURNSTILE_SECRET`, Value: the Secret key. Save. (Never put the secret key in script.js.)
5. Redeploy the script as a New version (step 3 above). Test one booking.
To turn it off later, delete the `TURNSTILE_SECRET` property.

## Sheet tabs: Today, Tomorrow, Archive (new)
- **Today** (green): bookings to collect today.
- **Tomorrow** (blue): bookings for tomorrow. After midnight these rows move to **Today** by themselves.
- **Archive** (grey): old bookings. After **4 PM**, today's rows move here automatically (the last column shows when). Nothing is deleted, so you keep the full history. Booking numbers keep counting up and are never reused.
- Status drop-down: **Booked**, **Collected**, **Cancelled**. Only Cancelled frees the slot.
- Today's rows disappear from the Today tab at 4 PM. If your team still works on them in the evening, change `ARCHIVE_HOUR` in Code.gs (for example 20 for 8 PM). It cannot be earlier than 16.
- Patients can only see slot counts, never the sheet. The Archive is as private as the rest of the sheet.

### One-time setup for the new tabs (do this after pasting the new Code.gs)
1. In Apps Script, in the function drop-down at the top choose **setupSheets** and click **Run**. Allow the permissions. This creates the three tabs and copies your existing bookings into them.
2. Your old "Bookings" tab is kept and renamed **Old Bookings (backup)**. Check that your data is in Today / Tomorrow / Archive, then you may delete the backup tab.
3. Choose **setupAutoArchive** and click **Run**. This makes the sheet tidy itself every hour (midnight rollover and 4 PM archive), even when nobody visits the website. To stop it, run **stopAutoArchive**.
4. Deploy > Manage deployments > pencil > Version: **New version** > Deploy.

Note: the move happens within about an hour after 4 PM (usually within minutes, because the website also triggers it when someone opens the booking form).
