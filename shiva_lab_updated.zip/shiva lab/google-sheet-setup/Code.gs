/**
 * Shiva Sathvika Lab - home collection bookings
 * Saves every booking in Google Sheets and allows only 50 per day (today and tomorrow only).
 *
 * Sheet tabs (created automatically):
 *   Today     (green)  bookings for today
 *   Tomorrow  (blue)   bookings for tomorrow; moves to Today after midnight
 *   Archive   (grey)   old bookings; today's rows move here after 4 PM
 * Paste this whole file in Apps Script.
 */
const LIMIT_PER_DAY = 50;          // change here if you ever need a different limit
const CUTOFF_HOUR = 16;            // 4 PM IST: bookings for a day close at 4 PM of that same day
const ARCHIVE_HOUR = 16;           // today's bookings move to Archive from this hour (IST). Must be 16 or later.
const MAX_PER_PHONE_PER_DAY = 3;   // one phone number can hold at most this many slots per day
const MAX_PER_MINUTE = 8;          // whole website: max booking attempts per minute (stops bots)
const SHEET_NAME = 'Bookings';     // the old single tab; its rows are copied once, then it is renamed (backup)
const BACKUP_NAME = 'Old Bookings (backup)';
const TAB_TODAY = 'Today', TAB_TOMORROW = 'Tomorrow', TAB_ARCHIVE = 'Archive';
const TZ = 'Asia/Kolkata';
const HEADERS = ['Booking No', 'Time', 'Collection Date', 'Day', 'Name', 'Age / Gender', 'Phone',
                 'Doctor', 'Landmark', 'Area', 'Tests', 'Status', 'Send confirmation'];
const ARCHIVE_HEADERS = HEADERS.slice(0, 12).concat(['Archived at']);
const STYLE = {   // tab colour, header colour, two row colours
  Today:    { tab: '#2e7d32', head: '#1b5e20', a: '#e8f5e9', b: '#c8e6c9' },
  Tomorrow: { tab: '#1565c0', head: '#0d47a1', a: '#e3f2fd', b: '#bbdefb' },
  Archive:  { tab: '#546e7a', head: '#37474f', a: '#fafafa', b: '#eceff1' }
};

/* ------------------------------------------------------------------ tabs */

function getTab_(name) {
  const ss = SpreadsheetApp.getActiveSpreadsheet();
  let sh = ss.getSheetByName(name);
  if (!sh) { sh = ss.insertSheet(name); setupTab_(sh, name); }
  return sh;
}

function setupTab_(sh, name) {
  const st = STYLE[name];
  if (sh.getMaxColumns() < 13) sh.insertColumnsAfter(sh.getMaxColumns(), 13 - sh.getMaxColumns());
  if (sh.getMaxRows() < 1000) sh.insertRowsAfter(sh.getMaxRows(), 1000 - sh.getMaxRows());
  sh.getRange(1, 1, 1, 13).setValues([name === TAB_ARCHIVE ? ARCHIVE_HEADERS : HEADERS])
    .setBackground(st.head).setFontColor('#ffffff').setFontWeight('bold');
  sh.setFrozenRows(1);
  sh.setTabColor(st.tab);
  sh.getRange('C:C').setNumberFormat('@');                  // keep dates as plain text yyyy-MM-dd
  [[1, 90], [2, 130], [3, 110], [4, 80], [5, 170], [6, 50], [7, 110], [8, 130], [9, 140], [10, 300], [11, 300], [12, 90], [13, 150]]
    .forEach(function (w) { sh.setColumnWidth(w[0], w[1]); });
  const range = sh.getRange('A2:M1000');
  const rule = function (formula) { return SpreadsheetApp.newConditionalFormatRule().whenFormulaSatisfied(formula).setRanges([range]); };
  sh.setConditionalFormatRules([
    rule('=OR(LOWER($L2)="cancelled",LOWER($L2)="canceled")').setBackground('#ffcdd2').setFontColor('#9e9e9e').setStrikethrough(true).build(),
    rule('=AND($A2<>"",ISEVEN(ROW()))').setBackground(st.a).build(),
    rule('=AND($A2<>"",ISODD(ROW()))').setBackground(st.b).build()
  ]);
  if (name !== TAB_ARCHIVE) {                               // Status drop-down (Cancelled frees the slot)
    sh.getRange('L2:L1000').setDataValidation(SpreadsheetApp.newDataValidation()
      .requireValueInList(['Booked', 'Collected', 'Cancelled'], true).setAllowInvalid(true).build());
  }
}

/* ---------------------------------------------------------------- helpers */

// Normalise a date cell to yyyy-MM-dd (cells may come back as Date objects or text)
function cellDate_(v) {
  if (v instanceof Date) return Utilities.formatDate(v, TZ, 'yyyy-MM-dd');
  return String(v == null ? '' : v).trim().slice(0, 10);
}
function dateFor_(offset) { return Utilities.formatDate(new Date(Date.now() + offset * 86400000), TZ, 'yyyy-MM-dd'); }
function hourIST_() { return Number(Utilities.formatDate(new Date(), TZ, 'H')); }
function archiveNow_() { return hourIST_() >= Math.max(CUTOFF_HOUR, ARCHIVE_HOUR); }
function dateObj_(date) { return new Date(date + 'T12:00:00+05:30'); }
function weekday_(date) { return Utilities.formatDate(dateObj_(date), TZ, 'EEE'); }
function isCancelled_(s) { s = String(s || '').trim().toLowerCase(); return s === 'cancelled' || s === 'canceled'; }

// Booking window: Today -> open until today 4 PM. Tomorrow -> always open.
function isOpen_(offset) { return offset === 0 ? hourIST_() < CUTOFF_HOUR : true; }

// One-tap WhatsApp reply for the lab team (column M). The wording follows the real date, so it stays correct after midnight.
function confirmFormula_(row, date) {
  const word = date === dateFor_(0) ? 'Today, ' : (date === dateFor_(1) ? 'Tomorrow, ' : '');
  const msg = encodeURIComponent('✅ Slot booked for ' + word + Utilities.formatDate(dateObj_(date), TZ, 'd MMM') +
    '. Our team will reach your home and collect the sample. - Shiva Sathvika Lab');
  return '=HYPERLINK("https://wa.me/91"&G' + row + '&"?text=' + msg + '","Send confirmation")';
}
function setConfirms_(sh, n, start) {
  start = start || 2;
  const dates = sh.getRange(start, 3, n, 1).getValues();
  for (let i = 0; i < n; i++) sh.getRange(start + i, 13).setFormula(confirmFormula_(start + i, cellDate_(dates[i][0])));
}

// All bookings that still count: the Today and Tomorrow tabs (columns A..L)
function liveRows_() {
  let all = [];
  [TAB_TODAY, TAB_TOMORROW].forEach(function (name) {
    const sh = getTab_(name), last = sh.getLastRow();
    if (last >= 2) all = all.concat(sh.getRange(2, 1, last - 1, 12).getValues());
  });
  return all;
}

// How many bookings already exist for each date (rows marked "Cancelled" do not count)
function countsByDate_(rows) {
  const counts = {};
  rows.forEach(function (r) {
    if (isCancelled_(r[11])) return;
    const d = cellDate_(r[2]);
    if (d) counts[d] = (counts[d] || 0) + 1;
  });
  return counts;
}

// Same person (name + phone) booking the same date again = reuse the first booking, do not use another slot
function findExisting_(rows, date, name, phone) {
  for (let i = 0; i < rows.length; i++) {
    const r = rows[i];
    if (isCancelled_(r[11])) continue;
    if (cellDate_(r[2]) === date && String(r[6]).replace(/\D/g, '') === phone &&
        String(r[4]).trim().toLowerCase() === name.trim().toLowerCase()) return r[0] || 1;
  }
  return 0;
}

// How many active bookings this phone number already has on this date
function phoneCount_(rows, date, phone) {
  let n = 0;
  rows.forEach(function (r) {
    if (!isCancelled_(r[11]) && cellDate_(r[2]) === date && String(r[6]).replace(/\D/g, '') === phone) n++;
  });
  return n;
}

// Highest booking number in the live tabs and the Archive, plus 1 (numbers are never reused)
function nextBookingNo_(rows) {
  let m = 0;
  rows.forEach(function (r) { m = Math.max(m, Number(r[0]) || 0); });
  const a = getTab_(TAB_ARCHIVE), last = a.getLastRow();
  if (last >= 2) a.getRange(2, 1, last - 1, 1).getValues().forEach(function (r) { m = Math.max(m, Number(r[0]) || 0); });
  return m + 1;
}

/* ------------------------------------------- moving rows (rollover + archive) */

function writeRows_(sh, name, rows) {
  const n = rows.length, start = sh.getLastRow() + 1;
  if (sh.getMaxRows() < start + n) sh.insertRowsAfter(sh.getMaxRows(), start + n - sh.getMaxRows());
  const stamp = Utilities.formatDate(new Date(), TZ, 'yyyy-MM-dd HH:mm');
  const vals = rows.map(function (r) {
    const v = r.slice(0, 12);
    v[1] = v[1] instanceof Date ? Utilities.formatDate(v[1], TZ, 'yyyy-MM-dd HH:mm') : v[1];
    v[2] = cellDate_(v[2]);
    v[3] = name === TAB_TODAY ? 'Today' : (name === TAB_TOMORROW ? 'Tomorrow' : weekday_(v[2]));
    v.push(name === TAB_ARCHIVE ? stamp : '');
    return v;
  });
  sh.getRange(start, 1, n, 13).setValues(vals);
  if (name !== TAB_ARCHIVE) setConfirms_(sh, n, start);
}

// Moves rows out of one tab. decide(date) returns the destination tab name, or null to leave the row.
// Rows are first copied to the destination, and only then removed here, so a failure can never lose a booking.
function moveRows_(srcName, decide) {
  const src = getTab_(srcName), last = src.getLastRow();
  if (last < 2) return;
  const rows = src.getRange(2, 1, last - 1, 12).getValues();
  const keep = [], out = {};
  rows.forEach(function (r) {
    const d = cellDate_(r[2]);
    if (!d && String(r[0]) === '') return;                       // blank row
    r[1] = r[1] instanceof Date ? Utilities.formatDate(r[1], TZ, 'yyyy-MM-dd HH:mm') : r[1];
    r[2] = d;
    const dest = d ? decide(d) : null;
    if (dest) (out[dest] = out[dest] || []).push(r); else keep.push(r);
  });
  const dests = Object.keys(out);
  if (!dests.length) return;
  dests.forEach(function (name) { writeRows_(getTab_(name), name, out[name]); });
  src.getRange(2, 1, last - 1, 13).clearContent();               // clear then rewrite (rows are never deleted, so the colours stay)
  if (keep.length) { src.getRange(2, 1, keep.length, 12).setValues(keep); setConfirms_(src, keep.length); }
}

// One-time: copies the rows of the old single "Bookings" tab into Today / Tomorrow / Archive, then renames it as a backup.
function migrateOld_() {
  const ss = SpreadsheetApp.getActiveSpreadsheet(), old = ss.getSheetByName(SHEET_NAME);
  if (!old) return;
  const today = dateFor_(0), tomorrow = dateFor_(1), last = old.getLastRow();
  const tabs = [TAB_TODAY, TAB_TOMORROW, TAB_ARCHIVE].map(getTab_);   // create the three tabs first
  if (last >= 2) {
    const out = {};
    old.getRange(2, 1, last - 1, 12).getValues().forEach(function (r) {
      const d = cellDate_(r[2]);
      if (!d && String(r[0]) === '') return;
      const dest = d === today ? TAB_TODAY : (d === tomorrow ? TAB_TOMORROW : TAB_ARCHIVE);
      (out[dest] = out[dest] || []).push(r);
    });
    Object.keys(out).forEach(function (name) { writeRows_(getTab_(name), name, out[name]); });
  }
  let backup = BACKUP_NAME;
  if (ss.getSheetByName(backup)) backup += ' ' + Utilities.formatDate(new Date(), TZ, 'yyyy-MM-dd HHmm');
  old.setName(backup);
  old.setTabColor('#9e9e9e');
}

// Brings every tab up to date:
//   1. Tomorrow's rows whose date has arrived move to Today (after midnight)
//   2. Today's rows move to Archive after 4 PM (and older rows at any time)
function runMaintenance_() {
  migrateOld_();
  const today = dateFor_(0), tomorrow = dateFor_(1), arch = archiveNow_();
  moveRows_(TAB_TOMORROW, function (d) { return d === today ? TAB_TODAY : (d < today ? TAB_ARCHIVE : null); });
  moveRows_(TAB_TODAY, function (d) {
    if (d < today || (d === today && arch)) return TAB_ARCHIVE;
    return d === tomorrow ? TAB_TOMORROW : null;
  });
}

// Caller must already hold the lock. Skips the work if nothing can have changed (same day, same side of 4 PM).
function maintainIfNeeded_(force) {
  const cache = CacheService.getScriptCache();
  const key = 'mt' + dateFor_(0) + (archiveNow_() ? 'a' : 'n');
  if (!force && cache.get(key)) return;
  runMaintenance_();
  cache.put(key, '1', 21600);
}

// Used by the website's slot check and by the hourly timer: takes the lock itself
function maintain_(force) {
  const lock = LockService.getScriptLock();
  if (!lock.tryLock(8000)) return;
  try { maintainIfNeeded_(force); } catch (err) { console.error(err); } finally { try { lock.releaseLock(); } catch (x) {} }
}

// Run this once after pasting the code: creates the tabs, copies your old bookings, and checks everything works
function setupSheets() { maintain_(true); }

// Run this once: makes the sheet tidy itself every hour (rollover after midnight, archive after 4 PM)
function setupAutoArchive() {
  stopAutoArchive();
  ScriptApp.newTrigger('archiveTick').timeBased().everyHours(1).create();
}
function stopAutoArchive() {
  ScriptApp.getProjectTriggers().forEach(function (t) {
    const f = t.getHandlerFunction();
    if (f === 'archiveTick' || f === 'deleteOldBookings') ScriptApp.deleteTrigger(t);
  });
}
function archiveTick() { maintain_(true); }

/* ------------------------------------------------------------ web app */

function slotsInfo_() {
  const counts = countsByDate_(liveRows_());
  return {
    limit: LIMIT_PER_DAY,
    days: [0, 1].map(function (o) {
      const date = dateFor_(o), booked = counts[date] || 0;
      return { offset: o, date: date, booked: booked, left: Math.max(0, LIMIT_PER_DAY - booked), open: isOpen_(o) };
    })
  };
}

function json_(obj) {
  return ContentService.createTextOutput(JSON.stringify(obj)).setMimeType(ContentService.MimeType.JSON);
}

// Stops text like =HYPERLINK(...) from running as a formula in the sheet
function safe_(v) {
  v = String(v == null ? '' : v).replace(/[\u0000-\u001F\u007F<>]/g, ' ').trim().slice(0, 500);   // no control characters or HTML brackets
  return /^[=+\-@]/.test(v) ? "'" + v : v;
}

// Spam protection: checks the Cloudflare Turnstile token. Only active when you add TURNSTILE_SECRET
// in Project Settings > Script properties (see SETUP-GOOGLE-SHEET.md). The secret is never in this file.
function turnstileOk_(token) {
  const secret = PropertiesService.getScriptProperties().getProperty('TURNSTILE_SECRET');
  if (!secret) return true;                                      // not set up: skip the check
  if (!token || String(token).length > 2048) return false;
  try {
    const r = UrlFetchApp.fetch('https://challenges.cloudflare.com/turnstile/v0/siteverify', {
      method: 'post', payload: { secret: secret, response: String(token) }, muteHttpExceptions: true
    });
    return JSON.parse(r.getContentText()).success === true;
  } catch (err) { console.error(err); return false; }
}

// Whole-site speed limit: at most MAX_PER_MINUTE booking attempts per minute
function throttled_() {
  const c = CacheService.getScriptCache();
  const k = 'rl' + Math.floor(Date.now() / 60000);
  const n = Number(c.get(k) || 0) + 1;
  c.put(k, String(n), 90);
  return n > MAX_PER_MINUTE;
}

function doGet(e) {
  try {
    maintain_(false);
    return json_(slotsInfo_());
  } catch (err) {
    console.error(err);
    return json_({ error: 'busy' });   // details stay in the Apps Script log, never sent to visitors
  }
}

function doPost(e) {
  const lock = LockService.getScriptLock();
  try {
    const raw = (e && e.postData && e.postData.contents) || '';
    if (raw.length > 6000) return json_({ ok: false, error: 'bad request' });   // real bookings are far smaller
    const b = JSON.parse(raw);
    if (b.hp) return json_({ ok: true });                       // spam trap
    if (throttled_()) return json_({ ok: false, error: 'busy' });
    const offset = Number(b.day);
    if (offset !== 0 && offset !== 1) return json_({ ok: false, error: 'bad day' });
    const phone = String(b.phone || '').replace(/\D/g, '');
    const age = Number(b.age);
    if (String(b.name || '').trim().length < 2 || !/^[6-9]\d{9}$/.test(phone) ||
        !(String(b.age || '').trim() !== '' && age >= 0 && age <= 120)) {
      return json_({ ok: false, error: 'bad details' });
    }
    if (!isOpen_(offset)) return json_({ ok: false, closed: true });   // today after 4 PM
    if (!turnstileOk_(b.ts)) return json_({ ok: false, error: 'security check failed' });   // done before the lock so others are not kept waiting

    lock.waitLock(20000);
    maintainIfNeeded_(false);
    const rows = liveRows_();
    const date = dateFor_(offset);
    if (findExisting_(rows, date, String(b.name), phone)) {
      return json_({ ok: true, duplicate: true });              // no booking number is revealed to whoever sent this
    }
    if (phoneCount_(rows, date, phone) >= MAX_PER_PHONE_PER_DAY) return json_({ ok: false, error: 'too many bookings for this number' });
    const booked = countsByDate_(rows)[date] || 0;
    if (booked >= LIMIT_PER_DAY) return json_({ ok: false, full: true });

    const bookingNo = nextBookingNo_(rows);
    const sh = getTab_(offset === 0 ? TAB_TODAY : TAB_TOMORROW);
    sh.appendRow([
      bookingNo,
      Utilities.formatDate(new Date(), TZ, 'yyyy-MM-dd HH:mm'),
      date,
      offset === 0 ? 'Today' : 'Tomorrow',
      safe_(b.name).slice(0, 80), String(age) + ' / ' + (['Male', 'Female', 'Other'].indexOf(b.gender) >= 0 ? b.gender : '-'), phone, safe_(b.doctor).slice(0, 80),
      safe_(b.landmark).slice(0, 120), safe_(String(b.area || '').slice(0, 60)), safe_(b.tests), 'Booked'
    ]);
    const row = sh.getLastRow();
    sh.getRange(row, 13).setFormula(confirmFormula_(row, date));
    return json_({ ok: true, bookingNo: bookingNo, left: LIMIT_PER_DAY - booked - 1 });
  } catch (err) {
    console.error(err);                                         // full detail stays in Apps Script > Executions
    return json_({ ok: false, error: 'busy' });                 // visitors only see a generic message
  } finally {
    try { lock.releaseLock(); } catch (x) {}
  }
}
